<?php \App\Models\SesionUsuario::getInstance()->onlyLogged() ?>

<?php $__env->startSection('title', 'Inicio de sesión'); ?>
<?php $__env->startSection('cuerpo'); ?>
    <h1>Bienvenido a la página home</h1>
    <br> <br>
    <h3>Has iniciado sesión con el usuario <?php echo e($_SESSION['usuario']); ?></h3>
    <br>
    <?php if($_SESSION['admin']): ?>
        <h3>Tienes permisos de administrador</h3>
    <?php else: ?>
        <h3>Tienes permisos de operario</h3>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp_dwes\htdocs\DWES\proyecto_hng\resources\views/home.blade.php ENDPATH**/ ?>