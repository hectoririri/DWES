
<?php $__env->startSection('title', 'Eliminar tarea'); ?>
<?php $__env->startSection('cuerpo'); ?>
<form method="post">
    <h2>¿Está seguro de que desea eliminar la siguiente tarea?</h2>
    <table class="table table-striped table-bordered">
        <tbody>
            <tr>
                <th>Nombre</th>
                <td><?php echo $tarea['nombre']; ?></td>
            </tr>
            <tr>
                <th>Apellidos</th>
                <td><?php echo $tarea['apellidos']; ?></td>
            </tr>
            <tr>
                <th>Descripción</th>
                <td><?php echo $tarea['descripcion']; ?></td>
            </tr>
            <tr>
                <th>Dirección</th>
                <td><?php echo $tarea['direccion']; ?></td>
            </tr>
            <tr>
                <th>Estado de la tarea</th>
                <td><?php echo $tarea['estado']; ?></td>
            </tr>
            <tr>
                <th>Fecha de realización</th>
                <td><?php echo $tarea['fecha_realizacion']; ?></td>
            </tr>
        </tbody>
    </table>
    <a href="<?php echo e(miurl('mostrar/tareas')); ?>" class="btn btn-outline-secondary d-inline-flex align-items-center">Cancelar</a>
    <button type="submit" name="boton" class="btn btn-danger d-inline-flex align-items-center">Eliminar</button>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp_dwes\htdocs\DWES\proyecto_hng\resources\views/borrar_tarea.blade.php ENDPATH**/ ?>