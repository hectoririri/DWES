
<?php $__env->startSection('title', 'Listado de Tareas'); ?>
<?php $__env->startSection('encabezado'); ?>
<ul>
    <li><a href="<?php echo miurl('tareas'); ?>">Añadir Tarea</a></li>
    <li><a href="#">Ver Tareas</a></li>
    <li><a href="">Prueba</a></li>
</ul>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('sidebar', 'menú lateral'); ?>
<?php $__env->startSection('cuerpo'); ?>
<ul>
<?php $__currentLoopData = $tareas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tarea): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li><?php echo e($tarea); ?></li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer', 'Pie de página'); ?>
<?php echo $__env->make('layout/plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp_dwes\htdocs\DWES\UT5\proyecto_hng\resources\views/tareas.blade.php ENDPATH**/ ?>