<?php $__env->startSection('title', 'Formulario De Creacion de Cuota'); ?>
<?php $__env->startSection('cuerpo'); ?>
<form method="POST" action="<?php echo e(route('cuotas.store')); ?>" enctype="multipart/form-data">

    <h2>Formulario de creación de cuota</h2>

    <?php echo $__env->make('cuotas.form_campos_cuota', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <a href="<?php echo e(route('cuotas.index')); ?>" class="btn btn-outline-secondary d-inline-flex align-items-center">Cancelar</a>
    <button type="submit" class="btn btn-primary d-inline-flex align-items-center">Enviar</button>
    <br> <br>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Workspace\DWES\Proyecto 2ºEval\resources\views/cuotas/form_crear_cuota.blade.php ENDPATH**/ ?>