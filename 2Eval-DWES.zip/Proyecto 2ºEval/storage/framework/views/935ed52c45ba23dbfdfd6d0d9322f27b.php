<?php $__env->startSection('title', 'Formulario'); ?>
<?php $__env->startSection('cuerpo'); ?>
<form method="POST" action="<?php echo e(route('tareas.update', ['tarea'=>$tarea])); ?>" enctype="multipart/form-data" class="bg-light p-4 rounded">
    <?php echo method_field('PATCH'); ?>
    <h2 class="text-secondary mb-5 text-center">Actualizando tarea Nº<?php echo e($tarea->id); ?></h2>
    
    <?php if(session('error')): ?>
    <div class="alert alert-danger">
        <?php echo e(session('error')); ?>

    </div>
    <?php endif; ?>    
    <?php echo $__env->make('tareas.form_campos_tarea', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="form-group">
        <label for="Fichero">Fichero resumen de tareas realizadas</label>
        <?php $__errorArgs = ['fichero'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <br>
                <div class="alert alert-danger"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <input type="file" class="form-control-file" name="fichero" id="Fichero">
    </div>
    
    <div class="form-group">
        <label for="foto">Fotos del trabajo realizado</label>
        <?php $__errorArgs = ['foto'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <br>
                <div class="alert alert-danger"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <input type="file" class="form-control-file" name="foto" id="foto">
    </div>

    <a href="<?php echo e(route('tareas.index')); ?>" class="btn btn-outline-secondary">Cancelar</a>
    <button type="submit" class="btn btn-primary">Enviar</button>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Workspace\DWES\Proyecto 2ºEval\resources\views/tareas/form_actualizar_tarea.blade.php ENDPATH**/ ?>