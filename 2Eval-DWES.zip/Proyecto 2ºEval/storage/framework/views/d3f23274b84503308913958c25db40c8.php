<?php $__env->startSection('title', 'Formulario para completar tarea'); ?>
<?php $__env->startSection('cuerpo'); ?>
<h2>Completar tarea</h2>

<table class="table table-striped table-bordered">
    <tbody>
        <?php $__currentLoopData = $tarea->toArray(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $valor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if(!in_array($index, ['id', 'cliente_id'])): ?>
            <tr>
                <th class="text-center"><?php echo e($index); ?></th>
                <td class="text-center"><?php echo e($valor); ?></td>
            </tr>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

<form method="POST" action="<?php echo e(route('confirmar.tarea', ['tarea'=>$tarea])); ?>" enctype="multipart/form-data">
    <?php echo method_field('PATCH'); ?>

    <input type="hidden" value="caquita">

    <label for="estado">Estado de la tarea*</label>
    <?php $__errorArgs = ['estado'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <br>
        <div class="alert alert-danger"><?php echo e($message); ?></div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <input type="radio" name="estado" value="R" id="estado" <?php if(old('estado', 'R') == 'R'): ?> checked <?php endif; ?>>R (Realizada)
    <input type="radio" name="estado" value="C" id="estado" <?php if(old('estado') == 'C'): ?> checked <?php endif; ?>>C (Cancelada)
    <br> <br>

    <label for="fecha_realizacion">Fecha y hora de realización de la tarea*</label>
    <?php $__errorArgs = ['fecha_realizacion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <br>
    <div class="alert alert-danger"><?php echo e($message); ?></div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>    
    <input type="datetime-local" name="fecha_realizacion" id="fecha_realizacion" value="<?php echo old('fecha_realizacion', $tarea->fecha_realizacion); ?>">
    <br> <br>

    <label for="anotaciones_posteriores">Anotaciones posteriores</label>
    <?php $__errorArgs = ['anotaciones_posteriores'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <br>
    <div class="alert alert-danger"><?php echo e($message); ?></div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <textarea name="anotaciones_posteriores" id="anotaciones_posteriores"><?php echo old('anotaciones_posteriores', $tarea->anotaciones_posteriores); ?></textarea>
    <br> <br>

    <a href="<?php echo route('tareas.index'); ?>" class="btn btn-outline-secondary d-inline-flex align-items-center">Cancelar</a>
    <button type="submit" class="btn btn-primary d-inline-flex align-items-center">Completar</button>
    <br> <br>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Workspace\DWES\Proyecto 2ºEval\resources\views/tareas/completar_tarea.blade.php ENDPATH**/ ?>