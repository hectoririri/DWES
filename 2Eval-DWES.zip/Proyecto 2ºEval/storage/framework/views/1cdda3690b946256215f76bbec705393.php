<?php $__env->startSection('title', 'Detalles de la tarea'); ?>
<?php $__env->startSection('cuerpo'); ?>
<?php
    use App\Models\Usuario;
    use App\Models\Cliente;
    use App\Models\Provincia;
?>
<h1 class="text-center">Detalles de la tarea Nº<?php echo e($tarea->id); ?></h1>
<?php if(session('mensaje')): ?>
    <div class="alert alert-success">
        <?php echo e(session('mensaje')); ?>

    </div>
<?php endif; ?>
<table class="table table-striped table-bordered text-center">
    <tbody>
        <tr>
            <td colspan="4" class="text-center">
                <a href="<?php echo route('tareas.index'); ?>" class="btn btn-outline-secondary d-inline-flex align-items-center justify-content-center w-25">Volver atrás</a>
                <?php if(auth()->user()->isAdmin()): ?>
                    <a href="<?php echo e(route('tareas.edit', ['tarea' => $tarea])); ?>" class="btn btn-outline-primary d-inline-flex align-items-center justify-content-center w-25">Modificar</a>
                    <button type="button" class="btn btn-outline-danger d-inline-flex align-items-center justify-content-center w-25" data-toggle="modal" data-target="#deleteModal">Borrar</button>
                    
                <?php endif; ?>
                <?php if(auth()->user()->isOperario() && ($tarea->estado == 'P' || $tarea->estado == 'B')): ?>
                     <a href="<?php echo route('completar.tarea', ['tarea' => $tarea]); ?>" class="btn btn-outline-success">Completar tarea</a>
                <?php endif; ?>
            </td>
        </tr>
        <tr>
            <th class="text-center" colspan="2">Descripción</th>
            <td class="text-center" colspan="2"><?php echo e($tarea->descripcion); ?></td>
        </tr>
        <tr>
            <th class="text-center" colspan="2">Dirección</th>
            <td class="text-center"  colspan="2"><?php echo e($tarea->direccion); ?></td>
        </tr>
        <tr>
            <th class="text-center" colspan="2">Población</th>
            <td class="text-center" colspan="2"><?php echo e($tarea->poblacion); ?></td>
        </tr>
        <tr>
            <th class="text-center" colspan="2">Código postal</th>
            <td class="text-center" colspan="2"><?php echo e($tarea->cod_postal); ?></td>
        </tr>
        <tr>
            <th class="text-center" colspan="2">Provincia</th>
            <td class="text-center" colspan="2"><?php echo e($tarea->getProvincia->nombre); ?></td>
        </tr>
        <tr>
            <th class="text-center" colspan="2">Estado</th>
            <td colspan="2">
                <?php if($tarea->estado == 'R'): ?>
                    <span class="bg-success text-white p-2 rounded">Realizado</span>
                <?php elseif($tarea->estado == 'C'): ?>
                    <span class="bg-danger text-white p-2 rounded">Cancelado</span>
                <?php elseif($tarea->estado == 'P'): ?>
                    <span class="bg-warning text-white p-2 rounded">Pendiente</span>
                <?php elseif($tarea->estado == 'B'): ?>
                    <span class="bg-primary text-white p-2 rounded">Por aprobar</span>
                <?php endif; ?>
            </td>
        </tr>
        <tr>
            <th class="text-center" colspan="2">Fecha de creación</th>
            <td class="text-center" colspan="2"><?php echo e($tarea->fecha_creacion); ?></td>
        </tr>
        <tr>
            <th class="text-center" colspan="2">Fecha de realización</th>
            <td class="text-center" colspan="2"><?php if($tarea->fecha_realizacion == null): ?> No realizada aún <?php else: ?> <?php echo e($tarea->fecha_realizacion); ?> <?php endif; ?></td>
        </tr>
        <tr>
            <th class="text-center" colspan="2">Fecha de actualización</th>
            <td class="text-center" colspan="2"> <?php if($tarea->fecha_actualizacion == null): ?> No actualizado aún <?php else: ?> <?php echo e($tarea->fecha_actualizacion); ?> <?php endif; ?> </td>
        </tr>
        <tr>
            <th class="text-center" colspan="2">Operario</th>
            <td class="text-center" colspan="2"><?php echo e($tarea->usuario == null ? 'Operario no asignado' : $tarea->usuario->name); ?></td>
            
        </tr>
        <tr>
            <th class="text-center" colspan="2">Cliente</th>
            <td class="text-center" colspan="2"><?php echo e($tarea->cliente == null ? 'Cliente no asignado' : $tarea->cliente->nombre); ?></td>
            
        </tr>
        <tr>
            <th class="text-center" colspan="2">Anotaciones anteriores</th>
            <td class="text-center" colspan="2"><?php echo e($tarea->anotaciones_anteriores); ?></td>
        </tr>
        <tr>
            <th class="text-center" colspan="2">Anotaciones posteriores</th>
            <td class="text-center" colspan="2"><?php echo e($tarea->anotaciones_posteriores); ?></td>
        </tr>
        <tr>
            <th class="text-center align-middle">Fichero</th>
            <td class="text-center align-middle">
                <?php if($tarea->fichero): ?>
                    <iframe width="380" height="550" src="<?php echo e($tarea->getTareaUrlAttribute()); ?>" frameborder="2"></iframe>
                    <br>
                    <a target="_blank" href="<?php echo e($tarea->getTareaUrlAttribute()); ?>">Abrir en otra pestaña</a>
                    <p><a href="<?php echo e($tarea->getTareaUrlAttribute()); ?>" download>Descargar</a></p>
                <?php else: ?>
                    No hay fichero disponible
                <?php endif; ?>
            </td>
            
            
            <th class="text-center align-middle">Foto</th>
            <td class="text-center align-middle">
                <?php if($tarea->foto): ?>
                    <img class="img-fluid sm" src="<?php echo e($tarea->getFotoUrlAttribute()); ?>" alt="<?php echo e($tarea->foto); ?>" />
                <?php else: ?>
                    No hay foto disponible
                <?php endif; ?>
            </td>
        </tr>
    </tbody>
</table>

  <!-- Modal -->
  <div class="modal fade" id="deleteModal" tabindex="-1" aria-labelledby="deleteModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="deleteModalLabel">¿Está seguro de que desea eliminar la tarea <?php echo e($tarea->id); ?>?</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          <table>
            <thead>
                <th>Descripción</th>
                <th>Dirección</th>
                <th>Estado</th>
                <th>Operario</th>
                <th>Cliente</th>
            </thead>
            <tbody>
                <tr>
                    <td><?php echo e($tarea->descripcion); ?></td>
                </tr>
            </tbody>
          </table>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          <a href="<?php echo e(route('tareas.index')); ?>" class="btn btn-danger">Borrar</a>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Workspace\DWES\Proyecto 2ºEval\resources\views/tareas/mostrar_tarea.blade.php ENDPATH**/ ?>