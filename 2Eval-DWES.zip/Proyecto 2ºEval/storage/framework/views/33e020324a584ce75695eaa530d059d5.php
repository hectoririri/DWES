
<?php $__env->startSection('title', 'Formulario para agregar tareas'); ?>
<?php $__env->startSection('sidebar', 'Menú lateral'); ?>
<?php $__env->startSection('cuerpo'); ?>
<form action="<?php echo e(miurl('formulario/alta')); ?>" method="post" enctype="multipart/form-data">
    
    <?php echo csrf_field(); ?> <?php echo e(csrf_field()); ?> 
    <h1>Formulario Agregar Tarea</h1>
    <label for="nif/cif">NIF o CIF* </label>
    <?php echo '<span>' . $errores->Error('nif/cif') . '</span>' ?>
    <input type="text" name="nif_cif" id="nif/cif" value="<?= $utiles->ValorPost('nif_cif') ?>">
    <br> <br>

    <label for="nombre">Nombre*</label>
    <?php echo '<span>' . $errores->Error('nombre') . '</span>'; ?>
    <input type="text" name="nombre" id="nombre" value="<?= $utiles->ValorPost('nombre') ?>">
    <br> <br>

    <label for="apellidos">Apellidos*</label>
    <?php echo '<span>' . $errores->Error('apellidos') . '</span>' ?>
    <input type="text" name="apellidos" id="apellidos" value="<?= $utiles->ValorPost('apellidos') ?>">
    <br> <br>

    <label for="telefono_contacto">Teléfono de contacto*</label>
    <?php echo '<span>' . $errores->Error('telefono') . '</span>' ?>
    <input type="text" name="telefono" id="telefono_contacto" value="<?= $utiles->ValorPost('telefono') ?>">
    <br> <br>

    <label for="descripcion">Descripción identificativa de la tarea*</label>
    <?php echo '<span>' . $errores->Error('descripcion') . '</span>' ?>
    <textarea name="descripcion" id="descripcion"><?= $utiles->ValorPost('descripcion') ?></textarea>
    <br> <br>

    <label for="correo">Correo electrónico*</label>
    <?php echo '<span>' . $errores->Error('correo') . '</span>' ?>
    <input type="text" name="correo" id="correo" value="<?= $utiles->ValorPost('correo') ?>">
    <br> <br>

    <label for="direccion">Dirección donde hay que ir a realizar la tarea</label>
    <?php echo '<span>' . $errores->Error('direccion') . '</span>' ?>
    <input type="text" name="direccion" id="direccion" value="<?= $utiles->ValorPost('direccion') ?>">
    <br> <br>

    <label for="poblacion">Población</label>
    <?php echo '<span>' . $errores->Error('poblacion') . '</span>' ?>
    <input type="text" name="poblacion" id="poblacion" value="<?= $utiles->ValorPost('poblacion') ?>">
    <br> <br>

    <label for="cod_postal">Código Postal*</label>
    <?php echo '<span>' . $errores->Error('cod_postal') . '</span>' ?>
    <input type="text" name="cod_postal" placeholder="ej: 21006" id="cod_postal" value="<?= $utiles->ValorPost('cod_postal') ?>">
    <br> <br>

    <label for="provincia">Provincia*</label>
    <?php echo '<span>' . $errores->Error('provincias') . '</span>' ?>
    <select name="provincias" id="provincia">
        <option value="" selected></option>
        <?php
        $conn = new mysqli("localhost", "root", "", "dbprovincias");
        $conn->set_charset("utf8");
        $reg = $conn->query('SELECT nombre FROM tbl_provincias;');
        while ($fila = $reg->fetch_assoc()) {
            echo '<option value="' . $fila['nombre'] . '"';
            echo ($utiles->ValorPost("provincias") == $fila['nombre']) ? ' selected' : '';
            echo '>' . $fila['nombre'] . '</option>';
        }
        ?>
    </select>
    <br> <br>

    <label for="estado">Estado de la tarea</label>
    <?php echo '<span>' . $errores->Error('estado') . '</span>' ?>
    <input type="radio" name="estado" value="P" id="estado" <?= $utiles->ValorPost('estado') == 'P' ? 'checked' : '' ?>>P (Pendiente)
    <input type="radio" name="estado" value="B" id="estado" <?= $utiles->ValorPost('estado') == 'B' ? 'checked' : '' ?>>B (Esperando ser aprobada)
    <input type="radio" name="estado" value="R" id="estado" <?= $utiles->ValorPost('estado') == 'R' ? 'checked' : '' ?>>R (Realizada)
    <input type="radio" name="estado" value="C" id="estado" <?= $utiles->ValorPost('estado') == 'C' ? 'checked' : '' ?>>C (Cancelada)
    <br> <br>

    <label for="fecha_creacion">Fecha de creación de la tarea</label>
    <input type="date" name="fecha_creacion" id="fecha_creacion" readonly value="<?php echo date('Y-m-d') ?>">
    <br> <br>

    <label for="operario">Operario encargado</label>
    <?php echo '<span>' . $errores->Error('operario_encargado') . '</span>' ?>
    <select name="operario_encargado" id="operario">
        <option value=""></option>
        <option value="Operario1" <?= $utiles->ValorPost('operario_encargado') == 'Operario1' ? 'selected' : '' ?>>Operario 1</option>
        <option value="Operario2" <?= $utiles->ValorPost('operario_encargado') == 'Operario2' ? 'selected' : '' ?>>Operario 2</option>
        <option value="Operario3" <?= $utiles->ValorPost('operario_encargado') == 'Operario3' ? 'selected' : '' ?>>Operario 3</option>
        <option value="Operario4" <?= $utiles->ValorPost('operario_encargado') == 'Operario4' ? 'selected' : '' ?>>Operario 4</option>
    </select>
    <br> <br>

    <label for="fecha_realizacion">Fecha de realización de la tarea*</label>
    <?php echo '<span>' . $errores->Error('fecha_realizacion') . '</span>' ?>
    <input type="date" name="fecha_realizacion" id="fecha_realizacion" value="<?= $utiles->ValorPost('fecha_realizacion') ?>">
    <br> <br>

    <label for="anotaciones_anteriores">Anotaciones anteriores</label>
    <textarea name="anotaciones_anteriores" id="anotaciones_anteriores"><?= $utiles->ValorPost('anotaciones_anteriores') ?></textarea>
    <br> <br>

    <label for="anotaciones_posteriores">Anotaciones posteriores</label>
    <textarea name="anotaciones_posteriores" id="anotaciones_posteriores"><?= $utiles->ValorPost('anotaciones_posteriores') ?></textarea>
    <br> <br>

    <label for="fichero">Fichero resumen de tareas realizadas</label>
    <input type="file" name="fichero_resumen" id="fichero">
    <br> <br>

    <label for="foto">Fotos del trabajo realizado</label>
    <input type="file" name="foto" id="foto">
    <br><br>

    <button type="submit" class="btn btn-primary d-inline-flex align-items-center">Enviar</button>
    <button type="reset" class="btn btn-outline-secondary d-inline-flex align-items-center">Reiniciar</button>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp_dwes\htdocs\DWES\UT5\proyecto_hng\resources\views/form_alta.blade.php ENDPATH**/ ?>