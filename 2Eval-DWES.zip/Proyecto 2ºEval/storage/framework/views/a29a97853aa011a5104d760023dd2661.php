
<?php $__env->startSection('title', 'Listado de Tareas'); ?>
<?php $__env->startSection('encabezado'); ?>
<ul>
    <li><a href="<?php echo miurl('tareas'); ?>">Añadir Tarea</a></li>
    <li><a href="#">Ver Tareas</a></li>
    <li><a href="">Prueba</a></li>
</ul>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('sidebar', 'menú lateral'); ?>
<?php $__env->startSection('cuerpo'); ?>
<h1>lista de las tareas</h1>
<h2><?php echo e(print_r($tareas)); ?></h2>
<ul>
<?php $__currentLoopData = $tareas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tarea): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php $__currentLoopData = $tarea; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($key); ?>: <?php echo e($value); ?></li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer', 'Pie de página'); ?>
<?php echo $__env->make('layout/plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\DWES\UT5\proyecto_hng\resources\views/tareas.blade.php ENDPATH**/ ?>