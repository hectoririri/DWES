<?php $__env->startSection('title', 'Página de inicio'); ?>
<?php $__env->startSection('cuerpo'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header"><h3>¡Te has logeado correctamente!</h3></div>

                <div class="card-body">
                    <p>Bienvenido a la pantalla de inicio, <b><?php echo e(auth()->user()->name); ?></b></p>
                    <p>Actualmente, tienes permisos de 
                        <?php if(auth()->user()->isAdmin()): ?>
                            <b>administrador</b>
                        <?php else: ?>
                            <b>operario</b>
                        <?php endif; ?>
                        </p>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Workspace\DWES\Proyecto 2ºEval\resources\views/auth/home.blade.php ENDPATH**/ ?>