<?php $__env->startSection('title', 'Formulario'); ?>
<?php $__env->startSection('cuerpo'); ?>
<form method="POST" action="<?php echo e(route('tareas.store')); ?>" enctype="multipart/form-data" class="bg-light p-4 rounded">
    <h1 class="text-primary text-center mb-5">Creando tarea</h1>

    <?php if(!auth()->check()): ?>
        <h3 class="text-secondary">Validese con una cuenta cliente registrada en nuestro sistema</h3>

        <div class="form-group">
            <label for="nif_cif">NIF o CIF*</label>
            <?php $__errorArgs = ['nif_cif'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <br>
                <div class="alert alert-danger"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <input type="text" class="form-control" name="nif_cif" id="nif_cif" value="<?php echo e(old('nif_cif', $tarea->nif_cif)); ?>">
        </div>
        
        <div class="form-group">
            <label for="telefono_contacto">Teléfono de contacto*</label>
            <?php $__errorArgs = ['telefono'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <br>
                <div class="alert alert-danger"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <input type="text" class="form-control" name="telefono" id="telefono_contacto" value="<?php echo e(old('telefono', $tarea->telefono)); ?>">
        </div>
    <?php endif; ?>

    
    <?php echo $__env->make('tareas.form_campos_tarea', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <a href="<?php echo e(route('tareas.index')); ?>" class="btn btn-outline-secondary">Cancelar</a>
    <button type="submit" class="btn btn-primary">Enviar</button>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Workspace\DWES\Proyecto 2ºEval\resources\views/tareas/form_crear_tarea.blade.php ENDPATH**/ ?>