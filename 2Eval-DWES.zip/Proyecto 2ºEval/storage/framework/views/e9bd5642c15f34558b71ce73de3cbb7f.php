<?php $__env->startSection('title', 'Formulario creación cliente'); ?>
<?php $__env->startSection('cuerpo'); ?>
<form method="POST" action="<?php echo e(route('clientes.store')); ?>" enctype="multipart/form-data" class="bg-light p-4 rounded">
    <h1 class="text-primary text-center mb-5">Creando cliente</h1>

    
    <?php echo $__env->make('clientes.form_campos_cliente', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <a href="<?php echo e(route('clientes.index')); ?>" class="btn btn-outline-secondary">Cancelar</a>
    <button type="submit" class="btn btn-primary">Enviar</button>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Workspace\DWES\Proyecto 2ºEval\resources\views/clientes/form_crear_cliente.blade.php ENDPATH**/ ?>