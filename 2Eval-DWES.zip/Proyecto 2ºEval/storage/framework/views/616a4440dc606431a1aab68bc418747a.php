

<div class="form-group">
    <label for="nif_cif">NIF o CIF*</label>
    <?php $__errorArgs = ['nif_cif'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <br>
        <div class="alert alert-danger"><?php echo e($message); ?></div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <input type="text" class="form-control" name="nif_cif" id="nif_cif" value="<?php echo e(old('nif_cif', $tarea->nif_cif)); ?>">
</div>

<div class="form-group">
    <label for="telefono_contacto">Teléfono de contacto*</label>
    <?php $__errorArgs = ['telefono'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <br>
        <div class="alert alert-danger"><?php echo e($message); ?></div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <input type="text" class="form-control" name="telefono" id="telefono_contacto" value="<?php echo e(old('telefono', $tarea->telefono)); ?>">
</div>

<div class="form-group">
    <label for="descripcion">Descripción identificativa de la tarea*</label>
    <?php $__errorArgs = ['descripcion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <br>
        <div class="alert alert-danger"><?php echo e($message); ?></div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <textarea class="form-control" name="descripcion" id="descripcion"><?php echo e(old('descripcion', $tarea->descripcion)); ?></textarea>
</div>

<div class="form-group">
    <label for="direccion">Dirección donde hay que ir a realizar la tarea</label>
    <?php $__errorArgs = ['direccion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <br>
        <div class="alert alert-danger"><?php echo e($message); ?></div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <input type="text" class="form-control" name="direccion" id="direccion" value="<?php echo e(old('direccion', $tarea->direccion)); ?>">
</div>

<div class="form-group">
    <label for="poblacion">Población</label>
    <?php $__errorArgs = ['poblacion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <br>
        <div class="alert alert-danger"><?php echo e($message); ?></div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <input type="text" class="form-control" name="poblacion" id="poblacion" value="<?php echo e(old('poblacion', $tarea->poblacion)); ?>">
</div>

<div class="form-group">
    <label for="cod_postal">Código Postal*</label>
    <?php $__errorArgs = ['cod_postal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <br>
        <div class="alert alert-danger"><?php echo e($message); ?></div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <input type="text" class="form-control" name="cod_postal" id="cod_postal" value="<?php echo e(old('cod_postal', $tarea->cod_postal)); ?>">
</div>

<div class="form-group">
    <label for="provincia">Provincia*</label>
    <?php $__errorArgs = ['provincia'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <br>
        <div class="alert alert-danger"><?php echo e($message); ?></div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <select class="form-control" name="provincia" id="provincia">
        <option value="" selected></option>
       <?php $__currentLoopData = $provincias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $provincia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($provincia->nombre); ?>" <?php echo e(old('provincia', $tarea->provincia) == $provincia->nombre ? 'selected' : ''); ?>><?php echo e($provincia->nombre); ?></option>
       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</div>

<div class="form-group">
    <label for="estado">Estado de la tarea</label>
    <?php $__errorArgs = ['estado'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <br>
        <div class="alert alert-danger"><?php echo e($message); ?></div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <div class="form-check">
        <input type="radio" class="form-check-input" name="estado" value="P" id="estado_P" <?php if(old('estado', $tarea->estado) == 'P'): ?> checked <?php endif; ?>>
        <label class="form-check-label" for="estado_P">P (Pendiente)</label>
    </div>
    <div class="form-check">
        <input type="radio" class="form-check-input" name="estado" value="B" id="estado_B" <?php if(old('estado', $tarea->estado) == 'B'): ?> checked <?php endif; ?>>
        <label class="form-check-label" for="estado_B">B (Esperando ser aprobada)</label>
    </div>
    <div class="form-check">
        <input type="radio" class="form-check-input" name="estado" value="R" id="estado_R" <?php if(old('estado', $tarea->estado) == 'R'): ?> checked <?php endif; ?>>
        <label class="form-check-label" for="estado_R">R (Realizada)</label>
    </div>
    <div class="form-check">
        <input type="radio" class="form-check-input" name="estado" value="C" id="estado_C" <?php if(old('estado', $tarea->estado) == 'C'): ?> checked <?php endif; ?>>
        <label class="form-check-label" for="estado_C">C (Cancelada)</label>
    </div>
</div>

<div class="form-group">
    <label for="fecha_creacion">Fecha de creación de la tarea</label>
    <?php $__errorArgs = ['fecha_creacion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <br>
        <div class="alert alert-danger"><?php echo e($message); ?></div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    
    <input type="datetime-local" class="form-control" name="fecha_creacion" id="fecha_creacion" <?php if(!empty($tarea->fecha_creacion)): ?> value="<?php echo e($tarea->fecha_creacion); ?>" <?php else: ?> value="<?php echo e(date("Y-m-d\\TH:i")); ?>" <?php endif; ?> readonly>
</div>


<div class="form-group">
    <label for="operario_id">Operario encargado*</label>
    <?php $__errorArgs = ['operario'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <br>
        <div class="alert alert-danger"><?php echo e($message); ?></div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <select class="form-control" name="operario" id="operario_id">
        <option value="" selected></option>
        <?php $__currentLoopData = $operarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $operario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($operario->id); ?>" <?php echo e(old('operario', $tarea->operario) == $operario->id ? 'selected' : ''); ?> ><?php echo e($operario->nombre." ".$operario->apellidos); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</div>


<div class="form-group">
    <label for="cliente_id">Cliente que encarga el trabajo*</label>
    <?php $__errorArgs = ['cliente'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <br>
        <div class="alert alert-danger"><?php echo e($message); ?></div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <select class="form-control" name="cliente" id="cliente_id">
        <option value="" selected></option>
        <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($cliente->id); ?>" <?php echo e(old('cliente', $tarea->cliente) == $cliente->id ? 'selected' : ''); ?> ><?php echo e($cliente->nombre." ".$cliente->apellidos); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</div>

<div class="form-group">
    <label for="fecha_realizacion">Fecha de realización de la tarea*</label>
    <?php $__errorArgs = ['fecha_realizacion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <br>
        <div class="alert alert-danger"><?php echo e($message); ?></div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <input type="datetime-local" class="form-control" name="fecha_realizacion" id="fecha_realizacion" value="<?php echo e(old('fecha_realizacion', $tarea->fecha_realizacion)); ?>">
</div>

<div class="form-group">
    <label for="anotaciones_anteriores">Anotaciones anteriores</label>
    <?php $__errorArgs = ['anotaciones_anteriores'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <br>
        <div class="alert alert-danger"><?php echo e($message); ?></div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <textarea class="form-control" name="anotaciones_anteriores" id="anotaciones_anteriores"><?php echo e(old('anotaciones_anteriores', $tarea->anotaciones_anteriores)); ?></textarea>
</div>

<div class="form-group">
    <label for="anotaciones_posteriores">Anotaciones posteriores</label>
    <?php $__errorArgs = ['anotaciones_posteriores'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <br>
        <div class="alert alert-danger"><?php echo e($message); ?></div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <textarea class="form-control" name="anotaciones_posteriores" id="anotaciones_posteriores"><?php echo e(old('anotaciones_posteriores', $tarea->anotaciones_posteriores)); ?></textarea>
</div><?php /**PATH C:\Workspace\DWES\Proyecto 2ºEval\resources\views/tareas/form_tarea_campos.blade.php ENDPATH**/ ?>