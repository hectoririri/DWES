<?php $__env->startSection('title', 'Eliminar usuario'); ?>
<?php $__env->startSection('cuerpo'); ?>
<form method="POST" action="<?php echo e(route('usuarios.destroy', ['usuario' => $usuario])); ?>">
    <?php echo method_field('DELETE'); ?>
    <h2>¿Está seguro de que desea eliminar al siguiente usuario?</h2>
    <table class="table table-striped table-bordered">
        <tbody>
            <tr>
                <th class="text-center">ID</th>
                <td class="text-center"><?php echo $usuario->id; ?></td>
            </tr>
            <tr>
                <th class="text-center">Nombre</th>
                <td class="text-center"><?php echo $usuario->name; ?></td>
            </tr>
            <tr>
                <th class="text-center">Correo Electrónico</th>
                <td class="text-center"><?php echo $usuario->email; ?></td>
            </tr>
            <tr>
                <th class="text-center">Rol</th>
                <td class="text-center"><?php echo e($usuario->rol == 'A' ? 'Administrador' : 'Operario'); ?></td>
            </tr>
            <tr>
                <th class="text-center">Fecha Alta</th>
                <td class="text-center"><?php echo $usuario->created_at; ?></td>
            </tr>
        </tbody>
    </table>
    <a href="<?php echo route('usuarios.index'); ?>" class="btn btn-outline-secondary d-inline-flex align-items-center">Cancelar</a>
    <button type="submit" name="boton" class="btn btn-danger d-inline-flex align-items-center">Eliminar</button>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Workspace\DWES\Proyecto 2ºEval\resources\views/usuarios/borrar_usuario.blade.php ENDPATH**/ ?>