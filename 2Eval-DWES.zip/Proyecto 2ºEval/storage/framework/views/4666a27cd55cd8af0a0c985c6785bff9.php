<?php $__env->startSection('title', 'Detalles de la tarea'); ?>
<?php $__env->startSection('cuerpo'); ?>
<h1 class="text-center">Detalles de la tarea Nº<?php echo e($tarea->id); ?></h1>
<?php if(session('mensaje')): ?>
    <div class="alert alert-success">
        <?php echo e(session('mensaje')); ?>

    </div>
<?php endif; ?>
<table class="table table-striped table-bordered text-center">
    <tbody>
        <?php $__currentLoopData = $tarea->toArray(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $valor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if(!in_array($index, ['id', 'cliente_id'])): ?>
            <tr>
                <th class="text-center"><?php echo e($index); ?></th>
                <td class="text-center"><?php echo e($valor); ?></td>
            </tr>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td colspan="3" class="text-center">
                <a href="<?php echo route('tareas.index'); ?>" class="btn btn-outline-secondary d-inline-flex align-items-center">Volver atrás</a>
                
                    
                    <a href="<?php echo route('confirmar.eliminar.tarea', ['tarea' => $tarea->id]); ?>" class="btn btn-outline-danger d-inline-flex align-items-center">Borrar</a>
                
                
                    
                
            </td>
        </tr>
    </tbody>
</table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout/plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Workspace\DWES\Proyecto 2ºEval\resources\views/mostrar_tarea.blade.php ENDPATH**/ ?>