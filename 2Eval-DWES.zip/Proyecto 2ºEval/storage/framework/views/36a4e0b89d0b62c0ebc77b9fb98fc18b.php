
<?php $__env->startSection('title', 'Listado de Tareas'); ?>
<?php $__env->startSection('sidebar', 'menú lateral'); ?>
<?php $__env->startSection('cuerpo'); ?>
<h1>lista de las tareas</h1>
<table class="table table-striped table-bordered">
    <thead class="thead-dark">
        <tr>
            
            <th>Descripción</th>
            <th>Operario</th>
            <th>Estado</th>
            <th>Anotaciones Anteriores</th>
            <th>Anotaciones Posteriores</th>
            <th>Provincia</th>
            <th>Fecha de Creación</th>
            <th>Fecha de Realización v</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $tareas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tarea): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($tarea['descripcion']); ?></td>
                <td><?php echo e($tarea['operario']); ?></td>
                <td><?php echo e($tarea['estado']); ?></td>
                <td><?php echo e($tarea['anotaciones_anteriores']); ?></td>
                <td><?php echo e($tarea['anotaciones_posteriores']); ?></td>
                <td><?php echo e($tarea['provincia']); ?></td>
                <td><?php echo e($tarea['fecha_creacion']); ?></td>
                <td><?php echo e($tarea['fecha_realizacion']); ?></td>
                <td><a href="<?php echo miurl("mostrar/tarea/{$tarea['id']}"); ?>">Ver completo</a></td>
                <td><a href="<?php echo miurl("modificar/tarea/{$tarea['id']}"); ?>">Modificar</a></td>
                <td><a href="<?php echo miurl("borrar/tarea/{$tarea['id']}"); ?>">Borrar</a></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer', 'Pie de página'); ?>
<?php echo $__env->make('layout/plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\DWES\UT5\proyecto_hng\resources\views/mostrar_tareas.blade.php ENDPATH**/ ?>