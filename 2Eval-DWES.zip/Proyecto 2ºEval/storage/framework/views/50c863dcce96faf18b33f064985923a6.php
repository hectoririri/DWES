<div class="form-group">
    <label for="concepto">Concepto*</label>
    <?php $__errorArgs = ['concepto'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <br>
        <div class="alert alert-danger"><?php echo e($message); ?></div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <input type="text" class="form-control" name="concepto" id="concepto" value="<?php echo e(old('concepto', $cuota->concepto)); ?>">
</div>

<div class="form-group">
    <label for="fecha_emision">Fecha Emisión*</label>
    <?php $__errorArgs = ['fecha_emision'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <br>
        <div class="alert alert-danger"><?php echo e($message); ?></div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <input type="datetime-local" class="form-control" name="fecha_emision" id="fecha_emision" value="<?php echo e(old('fecha_emision', $cuota->fecha_emision)); ?>">
</div>

<div class="form-group">
    <label for="importe">Importe*</label>
    <?php $__errorArgs = ['importe'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <br>
        <div class="alert alert-danger"><?php echo e($message); ?></div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <input type="text" class="form-control" name="importe" id="importe" value="<?php echo e(old('importe', $cuota->importe)); ?>">
</div>

<div class="form-group">
    <label for="fecha_pago">Fecha Pago*</label>
    <?php $__errorArgs = ['fecha_pago'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <br>
        <div class="alert alert-danger"><?php echo e($message); ?></div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <input type="datetime-local" class="form-control" name="fecha_pago" id="fecha_pago" value="<?php echo e(old('fecha_pago', $cuota->fecha_pago)); ?>">
</div>

<div class="form-group">
    <label for="notas">Notas</label>
    <?php $__errorArgs = ['notas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <br>
        <div class="alert alert-danger"><?php echo e($message); ?></div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <textarea name="notas" id="notas" cols="30" rows="2"><?php echo e(old('notas', $cuota->notas)); ?></textarea>
</div><?php /**PATH C:\Workspace\DWES\Proyecto 2ºEval\resources\views/cuotas/form_campos_cuota.blade.php ENDPATH**/ ?>