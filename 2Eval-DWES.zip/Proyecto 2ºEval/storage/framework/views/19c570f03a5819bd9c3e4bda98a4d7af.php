<div class="form-group">
    <label for="dni">DNI*</label>
    <?php $__errorArgs = ['dni'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <br>
        <div class="alert alert-danger"><?php echo e($message); ?></div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <input type="text" class="form-control" name="dni" id="dni" value="<?php echo e(old('dni', $usuario->dni)); ?>">
</div>

<div class="form-group">
    <label for="name">Nombre*</label>
    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <br>
        <div class="alert alert-danger"><?php echo e($message); ?></div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <input type="text" class="form-control" name="name" id="name" value="<?php echo e(old('name', $usuario->name)); ?>">
</div>

<div class="form-group">
    <label for="password">Contraseña*</label>
    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <br>
        <div class="alert alert-danger"><?php echo e($message); ?></div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <input type="password" class="form-control" name="password" id="password" value="<?php echo e(old('password', $usuario->password)); ?>">
</div>

<div class="form-group">
    <label for="email">Correo electrónico*</label>
    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <br>
        <div class="alert alert-danger"><?php echo e($message); ?></div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <input type="text" class="form-control" name="email" id="email" value="<?php echo e(old('email', $usuario->email)); ?>">
</div>

<div class="form-group">
    <label for="telefono">Telefono*</label>
    <?php $__errorArgs = ['telefono'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <br>
        <div class="alert alert-danger"><?php echo e($message); ?></div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <input type="text" class="form-control" name="telefono" id="telefono" value="<?php echo e(old('telefono', $usuario->telefono)); ?>">
</div>

<div class="form-group">
    <label for="direccion">Direccion*</label>
    <?php $__errorArgs = ['direccion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <br>
        <div class="alert alert-danger"><?php echo e($message); ?></div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <input type="text" class="form-control" name="direccion" id="direccion" value="<?php echo e(old('direccion', $usuario->direccion)); ?>">
</div>

<div class="form-group">
    <label for="rol">Rol*</label>
    <?php $__errorArgs = ['rol'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <br>
        <div class="alert alert-danger"><?php echo e($message); ?></div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <div class="form-check">
        <input type="radio" class="form-check-input" name="rol" value="A" id="rol_A" <?php if(old('rol', $usuario->rol) == 'A'): ?> checked <?php endif; ?>>
        <label class="form-check-label" for="rol_A">Administrador</label>
    </div>
    <div class="form-check">
        <input type="radio" class="form-check-input" name="rol" value="O" id="rol_O" <?php if(old('rol', $usuario->rol) == 'O'): ?> checked <?php endif; ?>>
        <label class="form-check-label" for="rol_O">Operario</label>
    </div>
</div><?php /**PATH C:\Workspace\DWES\Proyecto 2ºEval\resources\views/usuarios/form_campos_usuario.blade.php ENDPATH**/ ?>