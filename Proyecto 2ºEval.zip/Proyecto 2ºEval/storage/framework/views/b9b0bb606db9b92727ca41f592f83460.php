<?php $__env->startSection('title', 'Eliminar cliente'); ?>
<?php $__env->startSection('cuerpo'); ?>
<form method="POST" action="<?php echo e(route('clientes.destroy', ['cliente' => $cliente])); ?>">
    <?php echo method_field('DELETE'); ?>
    <h2>¿Está seguro de que desea eliminar al siguiente cliente?</h2>
    <table class="table table-hover table-bordered">
        <tbody>
            <tr class="table-secondary">
                <th class="text-center">ID</th>
                <td class="text-center"><?php echo $cliente->id; ?></td>
            </tr>
            <tr class="table-secondary">
                <th class="text-center">Nombre</th>
                <td class="text-center"><?php echo $cliente->nombre; ?></td>
            </tr>
            <tr class="table-secondary">
                <th class="text-center">Correo</th>
                <td class="text-center"><?php echo $cliente->correo; ?></td>
            </tr>
            <tr class="table-secondary">
                <th class="text-center">Cuenta Corriente</th>
                <td class="text-center"><?php echo $cliente->cuenta_corriente; ?></td>
            </tr>
            <tr class="table-secondary">
                <th class="text-center">Pais</th>
                <td class="text-center"><?php echo $cliente->pais; ?></td>
            </tr>
            <tr class="table-secondary">
                <th class="text-center">Moneda</th>
                <td class="text-center"><?php echo $cliente->moneda; ?></td>
            </tr>
            <tr class="table-secondary">
                <th class="text-center">Importe Mensual</th>
                <td class="text-center"><?php echo $cliente->importe_mensual; ?></td>
            </tr>
            <tr class="table-secondary">
                <th class="text-center">Fecha creación</th>
                <td class="text-center"><?php echo $cliente->fecha_creacion; ?></td>
            </tr>
        </tbody>
    </table>
    <a href="<?php echo e(route('clientes.index')); ?>" class="btn btn-outline-secondary d-inline-flex align-items-center">Cancelar</a>
    <button type="submit" name="boton" class="btn btn-danger d-inline-flex align-items-center">Eliminar</button>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Workspace\DWES\Proyecto 2ºEval\resources\views/clientes/borrar_cliente.blade.php ENDPATH**/ ?>