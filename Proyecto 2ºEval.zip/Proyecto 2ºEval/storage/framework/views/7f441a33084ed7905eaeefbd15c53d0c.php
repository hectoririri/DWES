<?php $__env->startSection('title', 'Formulario De Modificación Usuario'); ?>
<?php $__env->startSection('cuerpo'); ?>
<form method="POST" action="<?php echo e(route('usuarios.update', compact('usuario'))); ?>" enctype="multipart/form-data">
    <?php echo method_field('PUT'); ?>
    
    <?php if(auth()->user()->isAdmin()): ?>
    <h2>Formulario edición de usuario</h2>
    <?php echo $__env->make('usuarios.form_campos_usuario', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    <?php else: ?>
    <h2>Editando perfil</h2>
    <div class="form-group">
        <label for="email">Correo electrónico*</label>
        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <br>
            <div class="alert alert-danger"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <input type="text" class="form-control" name="email" id="email" value="<?php echo e(old('email', $usuario->email)); ?>">
    </div>

    <div class="form-group">
        <label for="fecha_creacion">Fecha de creación*</label>
        <?php $__errorArgs = ['fecha_creacion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <br>
            <div class="alert alert-danger"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <input type="datetime-local" class="form-control" name="fecha_creacion" id="fecha_creacion" value="<?php echo e(old('fecha_creacion', $usuario->fecha_creacion)); ?>">
    </div>
    <?php endif; ?>

    <a href="<?php echo e(route('usuarios.index')); ?>" class="btn btn-outline-secondary d-inline-flex align-items-center">Cancelar</a>
    <button type="submit" class="btn btn-primary d-inline-flex align-items-center">Enviar</button>
    <br> <br>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Workspace\DWES\Proyecto 2ºEval\resources\views/usuarios/form_editar_usuario.blade.php ENDPATH**/ ?>