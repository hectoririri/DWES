<?php \App\Models\SesionUsuario::getInstance()->onlyLogged() ?>
<?php if(!\App\Models\SesionUsuario::getInstance()->isAdmin()): ?>{
    <?php header('Location: ' . miurl('home')); exit(); ?>
}
<?php endif; ?>

<?php $__env->startSection('title', 'Formulario'); ?>
<?php $__env->startSection('cuerpo'); ?>
<form method="post" enctype="multipart/form-data">
    <h2><?php echo e($titulo); ?> tarea</h2>

    <label for="nif/cif">NIF o CIF* </label>
    <span><?php echo e($errores->Error('nif/cif')); ?></span>
    <input type="text" name="nif_cif" id="nif/cif" value="<?php echo e(($_POST) ? $utiles->valorPost('nif_cif') : ($tarea['nif_cif'] ?? '')); ?>">
    <br> <br>

    <label for="nombre">Nombre*</label>
    <span><?php echo e($errores->Error('nombre')); ?></span>
    <input type="text" name="nombre" id="nombre" value="<?php echo e(($_POST) ? $utiles->valorPost('nombre') : ($tarea['nombre'] ?? '')); ?>">
    <br> <br>

    <label for="apellidos">Apellidos*</label>
    <span><?php echo e($errores->Error('apellidos')); ?></span>
    <input type="text" name="apellidos" id="apellidos" value="<?php echo e(($_POST) ? $utiles->valorPost('apellidos') : ($tarea['apellidos'] ?? '')); ?>">
    <br> <br>

    <label for="telefono_contacto">Teléfono de contacto*</label>
    <span><?php echo e($errores->Error('telefono')); ?></span>
    <input type="text" name="telefono" id="telefono_contacto" value="<?php echo e(($_POST) ? $utiles->valorPost('telefono') : ($tarea['telefono'] ?? '')); ?>">
    <br> <br>

    <label for="descripcion">Descripción identificativa de la tarea*</label>
    <span><?php echo e($errores->Error('descripcion')); ?></span>
    <textarea name="descripcion" id="descripcion"><?php echo e(($_POST) ? $utiles->valorPost('descripcion') : ($tarea['descripcion'] ?? '')); ?></textarea>
    <br> <br>

    <label for="correo">Correo electrónico*</label>
    <span><?php echo e($errores->Error('correo')); ?></span>
    <input type="text" name="correo" id="correo" value="<?php echo e(($_POST) ? $utiles->valorPost('correo') : ($tarea['correo'] ?? '')); ?>" placeholder="ej: hola@gmail.com">
    <br> <br>

    <label for="direccion">Dirección donde hay que ir a realizar la tarea</label>
    <span><?php echo e($errores->Error('direccion')); ?></span>
    <input type="text" name="direccion" id="direccion" value="<?php echo e(($_POST) ? $utiles->valorPost('direccion') : ($tarea['direccion'] ?? '')); ?>">
    <br> <br>

    <label for="poblacion">Población</label>
    <span><?php echo e($errores->Error('poblacion')); ?></span>
    <input type="text" name="poblacion" id="poblacion" value="<?php echo e(($_POST) ? $utiles->valorPost('poblacion') : ($tarea['poblacion'] ?? '')); ?>">
    <br> <br>

    <label for="cod_postal">Código Postal*</label>
    <span><?php echo e($errores->Error('cod_postal')); ?></span>
    <input type="text" name="cod_postal" placeholder="ej: 21006" id="cod_postal" value="<?php echo e(($_POST) ? $utiles->valorPost('cod_postal') : ($tarea['cod_postal'] ?? '')); ?>">
    <br> <br>

    <label for="provincia">Provincia*</label>
    <span><?php echo e($errores->Error('provincia')); ?></span>
    <select name="provincia" id="provincia">
        <option value="" selected></option>
        <?php $__currentLoopData = $objTareas->recogerProvincias(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $provincia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($provincia); ?>" <?php echo e(($_POST) ? ($utiles->valorPost('provincia') == $provincia ? 'selected' : '') : (($tarea['provincia'] ?? '') == $provincia ? 'selected' : '')); ?>><?php echo e($provincia); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <br> <br>

    <label for="estado">Estado de la tarea</label>
    <span><?php echo e($errores->Error('estado')); ?></span>
    <input type="radio" name="estado" value="P" id="estado" <?php echo e(($_POST) ? ($utiles->valorPost('estado') == 'P' ? 'checked' : '') : (($tarea['estado'] ?? '') == 'P' ? 'checked' : '')); ?>>P (Pendiente)
    <input type="radio" name="estado" value="B" id="estado" <?php echo e(($_POST) ? ($utiles->valorPost('estado') == 'B' ? 'checked' : '') : (($tarea['estado'] ?? '') == 'B' ? 'checked' : '')); ?>>B (Esperando ser aprobada)
    <input type="radio" name="estado" value="R" id="estado" <?php echo e(($_POST) ? ($utiles->valorPost('estado') == 'R' ? 'checked' : '') : (($tarea['estado'] ?? '') == 'R' ? 'checked' : '')); ?>>R (Realizada)
    <input type="radio" name="estado" value="C" id="estado" <?php echo e(($_POST) ? ($utiles->valorPost('estado') == 'C' ? 'checked' : '') : (($tarea['estado'] ?? '') == 'C' ? 'checked' : '')); ?>>C (Cancelada)
    <br> <br>

    <label for="fecha_creacion">Fecha de creación de la tarea</label>
    <input type="date" name="fecha_creacion" id="fecha_creacion" readonly value="<?php echo e(empty($tarea['fecha_creacion']) ? date('Y-m-d') : $tarea['fecha_creacion']); ?>">
    <br> <br>

    <label for="operario">Operario encargado</label>
    <span><?php echo e($errores->Error('operario')); ?></span>
    <select name="operario" id="operario">
        <option value="" selected></option>
        <?php $__currentLoopData = $operarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $operario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($operario); ?>" <?php echo e(($_POST) ? ($utiles->valorPost('operario') == $operario ? 'selected' : '') : (($tarea['operario'] ?? '') == $operario ? 'selected' : '')); ?>><?php echo e($operario); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <br> <br>

    <label for="fecha_realizacion">Fecha de realización de la tarea*</label>
    <span><?php echo e($errores->Error('fecha_realizacion')); ?></span>
    <input type="date" name="fecha_realizacion" id="fecha_realizacion" value="<?php echo e(($_POST) ? $utiles->valorPost('fecha_realizacion') : ($tarea['fecha_realizacion'] ?? '')); ?>">
    <br> <br>

    <label for="anotaciones_anteriores">Anotaciones anteriores</label>
    <textarea name="anotaciones_anteriores" id="anotaciones_anteriores"><?php echo e(($_POST) ? $utiles->valorPost('anotaciones_anteriores') : ($tarea['anotaciones_anteriores'] ?? '')); ?></textarea>
    <br> <br>

    <label for="anotaciones_posteriores">Anotaciones posteriores</label>
    <textarea name="anotaciones_posteriores" id="anotaciones_posteriores"><?php echo e(($_POST) ? $utiles->valorPost('anotaciones_posteriores') : ($tarea['anotaciones_posteriores'] ?? '')); ?></textarea>
    <br> <br>

    <label for="fichero">Fichero resumen de tareas realizadas</label>
    <input type="file" name="fichero_resumen" id="fichero">
    <br> <br>

    <label for="foto">Fotos del trabajo realizado</label>
    <input type="file" name="foto" id="foto">
    <br><br>

    <a href="<?php echo e(miurl('mostrar/tareas')); ?>" class="btn btn-outline-secondary d-inline-flex align-items-center">Cancelar</a>
    <button type="submit" class="btn btn-primary d-inline-flex align-items-center">Enviar</button>
    <br> <br>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\DWES\proyecto_hng\resources\views/formulario_tarea.blade.php ENDPATH**/ ?>