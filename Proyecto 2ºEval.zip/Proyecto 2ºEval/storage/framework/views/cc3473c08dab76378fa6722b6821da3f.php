<div class="form-group">
    <label for="Cif">Cif del cliente*</label>
    <?php $__errorArgs = ['cif'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <br>
        <div class="alert alert-danger"><?php echo e($message); ?></div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <input type="text" class="form-control" name="cif" id="Cif" value="<?php echo e(old('cif', $cliente->cif)); ?>">
</div>

<div class="form-group">
    <label for="Nombre">Nombre del cliente</label>
    <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <br>
        <div class="alert alert-danger"><?php echo e($message); ?></div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <input type="text" class="form-control" name="nombre" id="Nombre" value="<?php echo e(old('nombre', $cliente->nombre)); ?>">
</div>

<div class="form-group">
    <label for="Telefono">Teléfono</label>
    <?php $__errorArgs = ['telefono'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <br>
        <div class="alert alert-danger"><?php echo e($message); ?></div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <input type="text" class="form-control" name="telefono" id="Telefono" value="<?php echo e(old('telefono', $cliente->telefono)); ?>">
</div>

<div class="form-group">
    <label for="CorreoElectronico">Correo electrónico*</label>
    <?php $__errorArgs = ['correo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <br>
        <div class="alert alert-danger"><?php echo e($message); ?></div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <input type="text" class="form-control" name="correo" id="CorreoElectronico" value="<?php echo e(old('correo', $cliente->correo)); ?>">
</div>

<div class="form-group">
    <label for="Pais">Pais*</label>
    <?php $__errorArgs = ['pais'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <br>
        <div class="alert alert-danger"><?php echo e($message); ?></div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <select class="form-control" name="pais" id="Pais">
        <option value="" selected></option>
       <?php $__currentLoopData = $paises; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pais): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($pais->id); ?>" <?php echo e(old('pais', $cliente->pais) == $pais->id ? 'selected' : ''); ?>><?php echo e($pais->nombre); ?></option>
       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</div>

<div class="form-group">
    <label for="CuentaCorriente">Cuenta Corriente</label>
    <?php $__errorArgs = ['cuenta_corriente'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <br>
        <div class="alert alert-danger"><?php echo e($message); ?></div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <input type="text" class="form-control" name="cuenta_corriente" id="CuentaCorriente" value="<?php echo e(old('cuenta_corriente', $cliente->cuenta_corriente)); ?>">
</div>

<div class="form-group">
    <label for="Moneda">Moneda</label>
    <?php $__errorArgs = ['moneda'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <br>
        <div class="alert alert-danger"><?php echo e($message); ?></div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <select class="form-control" name="moneda" id="Pais">
        <option value="" selected></option>
       <?php $__currentLoopData = $paises; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pais): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       <?php if($pais->iso_moneda != null): ?>
        <option value="<?php echo e($pais->iso_moneda); ?>" <?php echo e(old('moneda', $cliente->moneda) == $pais->iso_moneda ? 'selected' : ''); ?>><?php echo e($pais->iso_moneda); ?></option>
       <?php endif; ?>
       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</div>

<div class="form-group">
    <label for="ImporteMensual">Importe Mensual</label>
    <?php $__errorArgs = ['importe_mensual'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <br>
        <div class="alert alert-danger"><?php echo e($message); ?></div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    
    <input type="text" class="form-control" name="importe_mensual" id="ImporteMensual" value="<?php echo e(old('importe_mensual', $cliente->importe_mensual)); ?>">
</div><?php /**PATH C:\Workspace\DWES\Proyecto 2ºEval\resources\views/clientes/form_campos_cliente.blade.php ENDPATH**/ ?>