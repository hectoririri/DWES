<?php \App\Models\SesionUsuario::getInstance()->onlyLogged() ?>
<?php if(!\App\Models\SesionUsuario::getInstance()->isAdmin()): ?>{
    <?php header('Location: ' . miurl('home')); exit(); ?>
}
<?php endif; ?>

<?php $__env->startSection('title', 'Eliminar usuario'); ?>
<?php $__env->startSection('cuerpo'); ?>
<form method="post">
    <h2>¿Está seguro de que desea eliminar al siguiente usuario?</h2>
    <table class="table table-striped table-bordered">
        <tbody>
            <tr>
                <th>ID</th>
                <td><?php echo $usuario['id']; ?></td>
            </tr>
            <tr>
                <th>Nombre</th>
                <td><?php echo $usuario['nombre']; ?></td>
            </tr>
            <tr>
                <th>Contraseña</th>
                <td><?php echo $usuario['passwd']; ?></td>
            </tr>
            <tr>
                <th>Rol</th>
                <td><?php echo $usuario['rol']; ?></td>
            </tr>
        </tbody>
    </table>
    <a href="<?php echo miurl('mostrar/usuarios'); ?>" class="btn btn-outline-secondary d-inline-flex align-items-center">Cancelar</a>
    <button type="submit" name="boton" class="btn btn-danger d-inline-flex align-items-center">Eliminar</button>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\DWES\proyecto_hng\resources\views/borrar_usuario.blade.php ENDPATH**/ ?>