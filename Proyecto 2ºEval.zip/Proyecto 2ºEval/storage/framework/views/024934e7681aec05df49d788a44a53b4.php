
<?php $__env->startSection('title', 'Listado de Tareas'); ?>
<?php $__env->startSection('sidebar', 'menú lateral'); ?>
<?php $__env->startSection('cuerpo'); ?>
<h1>Detalles de la tarea Nº<?php echo e($tarea['id']); ?></h1>
<table class="table table-striped table-bordered">
    <thead class="thead-dark">
        <tr>
            
            <?php $__currentLoopData = array_keys($tarea); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <th><?php echo e($index); ?></th>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tr>
    </thead>
    <tbody> 
        <tr>
            <?php $__currentLoopData = $tarea; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $campo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <td><?php echo e($campo); ?></td>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <td><a href="<?php echo miurl("modificar/tarea/{$tarea['id']}"); ?>">Modificar</a></td>
                <td><a href="<?php echo miurl("borrar/tarea/{$tarea['id']}"); ?>">Borrar</a></td>
        </tr>
    </tbody>
</table>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer', 'Pie de página'); ?>
<?php echo $__env->make('layout/plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp_dwes\htdocs\DWES\UT5\proyecto_hng\resources\views/mostrar_tarea.blade.php ENDPATH**/ ?>