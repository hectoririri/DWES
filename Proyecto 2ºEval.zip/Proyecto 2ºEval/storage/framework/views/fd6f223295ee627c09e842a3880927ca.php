<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <style>
        span {
            color: red;
        }
    </style>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <header class="text-center my-4">
        <h1>Albañilería Bunglebuild S.L. </h1>
    </header>
    <main class="container mt-3">
        <div class="row">
            <div class="col-md-2">
                <?php if(!isset($mostrarMenu) || $mostrarMenu): ?>
                    <nav class="navbar navbar-expand-lg navbar-light bg-light">
                        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                            <span class="navbar-toggler-icon"></span>
                        </button>
                        <div class="collapse navbar-collapse" id="navbarNav">
                            <ul class="navbar-nav flex-column">
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo miurl('home'); ?>">Home</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo miurl('mostrar/tareas'); ?>">Mostrar Tareas</a>
                                </li>
                                <?php if(\App\Models\SesionUsuario::getInstance()->isAdmin()): ?>
                                    <li class="nav-item">
                                        <a class="nav-link" href="<?php echo miurl('formulario/alta/tarea'); ?>">Añadir Tarea</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="<?php echo miurl('mostrar/usuarios'); ?>">Mostrar usuarios</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="<?php echo miurl('formulario/alta/usuario'); ?>">Añadir usuario</a>
                                    </li>
                                <?php endif; ?>
                                
                            </ul>
                        </div>
                    </nav>
                <?php endif; ?>
            </div>
            <div class="col-md-10">
                <?php if(!isset($mostrarMenu) || $mostrarMenu): ?>
                <div class="d-flex justify-content-end">
                    <a href="<?php echo miurl('loggout'); ?>">Cerrar sesión</a>
                </div>
                <?php endif; ?>
                <?php echo $__env->yieldContent('cuerpo'); ?>
            </div>
        </div>
    </main>
    <footer class="text-center mt-4">
        <?php echo $__env->yieldContent('footer'); ?>
    </footer>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html><?php /**PATH C:\xampp\htdocs\DWES\proyecto_hng\resources\views/layout/plantilla.blade.php ENDPATH**/ ?>