<?php $__env->startSection('title', 'Eliminar tarea'); ?>
<?php $__env->startSection('cuerpo'); ?>
<form method="POST" action="<?php echo e(route('tareas.destroy', ['tarea' => $tarea])); ?>">
    <?php echo method_field('DELETE'); ?>
    <h2>¿Está seguro de que desea eliminar la siguiente tarea?</h2>
    <table class="table table-hover table-bordered">
        <tbody>
            <tr class="table-secondary">
                <th class="text-center">ID</th>
                <td class="text-center"><?php echo $tarea->id; ?></td>
            </tr>
            <tr class="table-secondary">
                <th class="text-center">Nombre</th>
                <td class="text-center"><?php echo $tarea->nombre; ?></td>
            </tr>
            <tr class="table-secondary">
                <th class="text-center">Apellidos</th>
                <td class="text-center"><?php echo $tarea->apellidos; ?></td>
            </tr>
            <tr class="table-secondary">
                <th class="text-center">Provincia</th>
                <td class="text-center"><?php echo $tarea->provincia; ?></td>
            </tr>
            <tr class="table-secondary">
                <th class="text-center">Descripción</th>
                <td class="text-center"><?php echo $tarea->descripcion; ?></td>
            </tr>
            <tr class="table-secondary">
                <th class="text-center">Dirección</th>
                <td class="text-center"><?php echo $tarea->direccion; ?></td>
            </tr>
            <tr class="table-secondary">
                <th class="text-center">Estado de la tarea</th>
                <td class="text-center"><?php echo $tarea->estado; ?></td>
            </tr>
            <tr class="table-secondary">
                <th class="text-center">Fecha de realización</th>
                <td class="text-center"><?php echo $tarea->fecha_realizacion; ?></td>
            </tr>
        </tbody>
    </table>
    <a href="<?php echo e(route('tareas.index')); ?>" class="btn btn-outline-secondary d-inline-flex align-items-center">Cancelar</a>
    <button type="submit" name="boton" class="btn btn-danger d-inline-flex align-items-center">Eliminar</button>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Workspace\DWES\Proyecto 2ºEval\resources\views/tareas/borrar_tarea.blade.php ENDPATH**/ ?>