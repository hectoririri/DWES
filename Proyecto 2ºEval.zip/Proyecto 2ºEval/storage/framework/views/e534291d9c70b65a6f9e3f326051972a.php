<div class="form-group">
    <label for="nif_cif">NIF o CIF*</label>
    <?php $__errorArgs = ['nif_cif'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <br>
        <div class="alert alert-danger"><?php echo e($message); ?></div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <input type="text" class="form-control" name="nif_cif" id="nif_cif" value="<?php echo e(old('nif_cif', $tarea->nif_cif)); ?>">
</div>

<div class="form-group">
    <label for="nombre">Nombre*</label>
    <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <br>
        <div class="alert alert-danger"><?php echo e($message); ?></div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <input type="text" class="form-control" name="nombre" id="nombre" value="<?php echo e(old('nombre')); ?>">
</div>

<div class="form-group">
    <label for="apellidos">Apellidos*</label>
    <?php $__errorArgs = ['apellidos'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <br>
        <div class="alert alert-danger"><?php echo e($message); ?></div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <input type="text" class="form-control" name="apellidos" id="apellidos" value="<?php echo e(old('apellidos')); ?>">
</div>

<div class="form-group">
    <label for="telefono_contacto">Teléfono de contacto*</label>
    <?php $__errorArgs = ['telefono'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <br>
        <div class="alert alert-danger"><?php echo e($message); ?></div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <input type="text" class="form-control" name="telefono" id="telefono_contacto" value="<?php echo e(old('telefono')); ?>">
</div>

<div class="form-group">
    <label for="descripcion">Descripción identificativa de la tarea*</label>
    <?php $__errorArgs = ['descripcion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <br>
        <div class="alert alert-danger"><?php echo e($message); ?></div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <textarea class="form-control" name="descripcion" id="descripcion"><?php echo e(old('descripcion')); ?></textarea>
</div>

<div class="form-group">
    <label for="correo">Correo electrónico*</label>
    <?php $__errorArgs = ['correo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <br>
        <div class="alert alert-danger"><?php echo e($message); ?></div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <input type="text" class="form-control" name="correo" id="correo" value="<?php echo e(old('correo')); ?>">
</div>

<div class="form-group">
    <label for="direccion">Dirección donde hay que ir a realizar la tarea</label>
    <?php $__errorArgs = ['direccion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <br>
        <div class="alert alert-danger"><?php echo e($message); ?></div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <input type="text" class="form-control" name="direccion" id="direccion" value="<?php echo e(old('direccion')); ?>">
</div>

<div class="form-group">
    <label for="poblacion">Población</label>
    <?php $__errorArgs = ['poblacion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <br>
        <div class="alert alert-danger"><?php echo e($message); ?></div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <input type="text" class="form-control" name="poblacion" id="poblacion" value="<?php echo e(old('poblacion')); ?>">
</div>

<div class="form-group">
    <label for="cod_postal">Código Postal*</label>
    <?php $__errorArgs = ['cod_postal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <br>
        <div class="alert alert-danger"><?php echo e($message); ?></div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <input type="text" class="form-control" name="cod_postal" id="cod_postal" value="<?php echo e(old('cod_postal')); ?>">
</div>

<div class="form-group">
    <label for="provincia">Provincia*</label>
    <?php $__errorArgs = ['provincia'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <br>
        <div class="alert alert-danger"><?php echo e($message); ?></div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <select class="form-control" name="provincia" id="provincia">
        <option value="" selected></option>
       <?php $__currentLoopData = $provincias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $provincia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($provincia->nombre); ?>" <?php if(old('provincia') == $provincia->nombre): ?> selected <?php endif; ?>><?php echo e($provincia->nombre); ?></option>
       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</div>

<div class="form-group">
    <label for="estado">Estado de la tarea</label>
    <?php $__errorArgs = ['estado'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <br>
        <div class="alert alert-danger"><?php echo e($message); ?></div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <div class="form-check">
        <input type="radio" class="form-check-input" name="estado" value="P" id="estado_P" <?php if(old('estado') == 'P'): ?> checked <?php endif; ?>>
        <label class="form-check-label" for="estado_P">P (Pendiente)</label>
    </div>
    <div class="form-check">
        <input type="radio" class="form-check-input" name="estado" value="B" id="estado_B" <?php if(old('estado') == 'B'): ?> checked <?php endif; ?>>
        <label class="form-check-label" for="estado_B">B (Esperando ser aprobada)</label>
    </div>
    <div class="form-check">
        <input type="radio" class="form-check-input" name="estado" value="R" id="estado_R" <?php if(old('estado') == 'R'): ?> checked <?php endif; ?>>
        <label class="form-check-label" for="estado_R">R (Realizada)</label>
    </div>
    <div class="form-check">
        <input type="radio" class="form-check-input" name="estado" value="C" id="estado_C" <?php if(old('estado') == 'C'): ?> checked <?php endif; ?>>
        <label class="form-check-label" for="estado_C">C (Cancelada)</label>
    </div>
</div>

<div class="form-group">
    <label for="fecha_creacion">Fecha de creación de la tarea</label>
    <?php $__errorArgs = ['fecha_creacion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <br>
        <div class="alert alert-danger"><?php echo e($message); ?></div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <input type="date" class="form-control" name="fecha_creacion" id="fecha_creacion" value="<?php echo e(date('Y-m-d')); ?>" readonly>
</div>


<div class="form-group">
    <label for="operario">Operario encargado*</label>
    <?php $__errorArgs = ['operario'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <br>
        <div class="alert alert-danger"><?php echo e($message); ?></div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <select class="form-control" name="operario" id="operario_id">
        <option value="" selected></option>
        <?php $__currentLoopData = $operarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $operario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($operario->id); ?>" <?php if(old('operario') == $operario->id): ?> selected <?php endif; ?> ><?php echo e($operario->nombre." ".$operario->apellidos); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</div>

<div class="form-group">
    <label for="fecha_realizacion">Fecha de realización de la tarea*</label>
    <?php $__errorArgs = ['fecha_realizacion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <br>
        <div class="alert alert-danger"><?php echo e($message); ?></div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <input type="date" class="form-control" name="fecha_realizacion" id="fecha_realizacion" value=" <?php echo e(old('fecha_realizacion')); ?>">
</div>

<div class="form-group">
    <label for="anotaciones_anteriores">Anotaciones anteriores</label>
    <?php $__errorArgs = ['anotaciones_anteriores'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <br>
        <div class="alert alert-danger"><?php echo e($message); ?></div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <textarea class="form-control" name="anotaciones_anteriores" id="anotaciones_anteriores"><?php echo e(old('anotaciones_anteriores')); ?></textarea>
</div>

<div class="form-group">
    <label for="anotaciones_posteriores">Anotaciones posteriores</label>
    <?php $__errorArgs = ['anotaciones_posteriores'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <br>
        <div class="alert alert-danger"><?php echo e($message); ?></div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <textarea class="form-control" name="anotaciones_posteriores" id="anotaciones_posteriores"><?php echo e(old('anotaciones_posteriores')); ?></textarea>
</div>

<div class="form-group">
    <label for="fichero">Fichero resumen de tareas realizadas</label>
    <input type="file" class="form-control-file" name="fichero_resumen" id="fichero">
</div>

<div class="form-group">
    <label for="foto">Fotos del trabajo realizado</label>
    <input type="file" class="form-control-file" name="foto" id="foto">
</div><?php /**PATH C:\Workspace\DWES\Proyecto 2ºEval\resources\views/formulario_tarea_campos.blade.php ENDPATH**/ ?>