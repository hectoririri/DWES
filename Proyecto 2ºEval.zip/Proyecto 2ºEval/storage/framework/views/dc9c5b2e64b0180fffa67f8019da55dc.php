
<?php $__env->startSection('title', 'Detalles del usuario'); ?>
<?php $__env->startSection('cuerpo'); ?>
<h1 class="text-center">Detalles del usuario <?php echo e($usuario['nombre']); ?></h1>
<table class="table table-striped table-bordered text-center">
    <tbody>
        <?php $__currentLoopData = $usuario; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th class="text-center"><?php echo e($key); ?></th>
                <td class="text-center"><?php echo e($value); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td colspan="3" class="text-center">
                <a href="<?php echo miurl("mostrar/usuarios"); ?>" class="btn btn-outline-secondary d-inline-flex align-items-center">Volver atrás</a>
                <a href="<?php echo miurl("modificar/usuario/{$usuario['id']}"); ?>" class="btn btn-outline-primary d-inline-flex align-items-center">Modificar</a>
                <a href="<?php echo miurl("borrar/usuario/{$usuario['id']}"); ?>" class="btn btn-outline-danger d-inline-flex align-items-center">Borrar</a>
            </td>
        </tr>
    </tbody>
</table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout/plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp_dwes\htdocs\DWES\proyecto_hng\resources\views/mostrar_usuario.blade.php ENDPATH**/ ?>