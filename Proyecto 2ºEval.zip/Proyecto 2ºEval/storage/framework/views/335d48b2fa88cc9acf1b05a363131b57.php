<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo $__env->yieldContent('title'); ?></title>
</head>
<body>
    <nav>
        <?php echo $__env->yieldContent('nav'); ?>
    </nav>
    <main>
        <?php echo $__env->yieldContent('main'); ?>
    </main>
    <footer>
        <?php echo $__env->yieldContent('footer'); ?>
    </footer>
</body>
</html><?php /**PATH C:\xampp\htdocs\DWES\UT5\proyecto_hng\resources\views/layout.blade.php ENDPATH**/ ?>