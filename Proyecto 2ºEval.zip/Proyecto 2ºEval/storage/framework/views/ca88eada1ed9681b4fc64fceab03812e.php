<?php \App\Models\SesionUsuario::getInstance()->onlyLogged() ?>

<?php $__env->startSection('title', 'Detalles de la tarea'); ?>
<?php $__env->startSection('cuerpo'); ?>
<h1 class="text-center">Detalles de la tarea Nº<?php echo e($tarea['id']); ?></h1>
<table class="table table-striped table-bordered text-center">
    <tbody>
        <?php $__currentLoopData = $tarea; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th class="text-center"><?php echo e($key); ?></th>
                <td class="text-center"><?php echo e($value); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td colspan="3" class="text-center">
                <a href="<?php echo miurl("mostrar/tareas"); ?>" class="btn btn-outline-secondary d-inline-flex align-items-center">Volver atrás</a>
                <?php if(\App\Models\SesionUsuario::getInstance()->isAdmin()): ?>
                    <a href="<?php echo miurl("modificar/tarea/{$tarea['id']}"); ?>" class="btn btn-outline-primary d-inline-flex align-items-center">Modificar</a>
                    <a href="<?php echo miurl("borrar/tarea/{$tarea['id']}"); ?>" class="btn btn-outline-danger d-inline-flex align-items-center">Borrar</a>
                <?php endif; ?>
                <?php if(!\App\Models\SesionUsuario::getInstance()->isAdmin() && ($tarea['estado'] == 'P' || $tarea['estado'] == 'B')): ?>
                    <a href="<?php echo miurl("completar/tarea/{$tarea['id']}"); ?>" class="btn btn-outline-success">Completar tarea</a>
                <?php endif; ?>
            </td>
        </tr>
    </tbody>
</table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout/plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\DWES\proyecto_hng\resources\views/mostrar_tarea.blade.php ENDPATH**/ ?>