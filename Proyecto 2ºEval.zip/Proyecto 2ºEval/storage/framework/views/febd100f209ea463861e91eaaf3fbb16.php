
<?php $__env->startSection('title', 'Inicio de sesión'); ?>
<?php $__env->startSection('cuerpo'); ?>
    <h1>Inicio de sesión</h1>
    <form method="POST" action="<?php echo e(miurl('')); ?>">
        <label for="usuario">Nombre usuario:</label>
        <input type="text" name="usuario" id="usuario" value="<?php echo e(($_POST) ? $utiles->valorPost('usuario') : (isset($_COOKIE['usuario']) ? $_COOKIE['usuario'] : '')); ?>">
        <label for="passwd">Contraseña:</label>
        <input type="password" name="passwd" id="passwd" value="<?php echo e(($_POST) ? '' : (isset($_COOKIE['passwd']) ? $_COOKIE['passwd'] : '')); ?>">
        <br>
        <span>
            <?php if(isset($error)): ?>
                <?php echo e($error); ?>

            <?php endif; ?>
        </span>
        <br>
        <input type="checkbox" name="recordar" id="recordar">
        <label for="recordar">Recordarme</label>
        <br>
        <button type="submit">Iniciar sesión</button>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\DWES\proyecto_hng\resources\views/login.blade.php ENDPATH**/ ?>