
<?php $__env->startSection('title', 'Bienvenida'); ?>
<?php $__env->startSection('sidebar', 'menú lateral'); ?>
<?php $__env->startSection('cuerpo', 'Contenido de la página'); ?>
<?php $__env->startSection('footer', 'Pie de página'); ?>
<?php echo $__env->make('layout/plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp_dwes\htdocs\DWES\UT5\proyecto_hng\resources\views/index.blade.php ENDPATH**/ ?>