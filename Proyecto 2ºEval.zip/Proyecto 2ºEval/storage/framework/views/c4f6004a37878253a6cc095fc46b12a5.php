<?php \App\Models\SesionUsuario::getInstance()->onlyLogged()?>
<?php if(!\App\Models\SesionUsuario::getInstance()->isAdmin()): ?>{
    <?php header('Location: ' . miurl('home')); exit(); ?>
}
<?php endif; ?>

<?php $__env->startSection('title', 'Formulario De Alta Usuario'); ?>
<?php $__env->startSection('cuerpo'); ?>
<form method="post" enctype="multipart/form-data">
    <h2><?php echo e($titulo); ?> usuario</h2>

    <label for="nombre">Nombre*</label>
    <span><?php echo e($errores->Error('nombre')); ?></span>
    <input type="text" name="nombre" id="nombre" value="<?php echo e(($_POST) ? $utiles->valorPost('nombre') : ($usuario['nombre'] ?? '')); ?>">
    <br> <br>

    <label for="passwd">Contraseña*</label>
    <span><?php echo e($errores->Error('passwd')); ?></span>
    <input type="text" name="passwd" id="passwd" value="<?php echo e(($_POST) ? $utiles->valorPost('passwd') : ($usuario['passwd'] ?? '')); ?>">
    <br> <br>

    <label for="rol">Rol*</label>
    <span><?php echo e($errores->Error('rol')); ?></span>
    <input type="radio" name="rol" value="A" id="rol" <?php echo e(($_POST) ? ($utiles->valorPost('rol') == 'A' ? 'checked' : '') : (($usuario['rol'] ?? '') == 'A' ? 'checked' : '')); ?>> A (Admin)
    <input type="radio" name="rol" value="O" id="rol" <?php echo e(($_POST) ? ($utiles->valorPost('rol') == 'O' ? 'checked' : '') : (($usuario['rol'] ?? '') == 'O' ? 'checked' : '')); ?>> O (Operario)
    <br> <br>

    <a href="<?php echo e(miurl('mostrar/usuarios')); ?>" class="btn btn-outline-secondary d-inline-flex align-items-center">Cancelar</a>
    <button type="submit" class="btn btn-primary d-inline-flex align-items-center">Enviar</button>
    <br> <br>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\DWES\proyecto_hng\resources\views/formulario_usuario.blade.php ENDPATH**/ ?>