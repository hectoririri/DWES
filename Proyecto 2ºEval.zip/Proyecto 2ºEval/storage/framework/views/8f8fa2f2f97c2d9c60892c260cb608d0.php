<?php \App\Models\SesionUsuario::getInstance()->onlyLogged() ?>

<?php $__env->startSection('title', 'Inicio de sesión'); ?>
<?php $__env->startSection('cuerpo'); ?>
    <h1>Bienvenido a la página home</h1>
    <h3>Has iniciado sesión con el usuario <?php echo e($_SESSION['usuario']); ?></h3>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\DWES\proyecto_hng\resources\views/home.blade.php ENDPATH**/ ?>